# Utility Scripts

This folder contains utility scripts. They are not used anywhere in the codebase. Their only purpose is to help us finding anomalies in our dataset and fix them quickly.
