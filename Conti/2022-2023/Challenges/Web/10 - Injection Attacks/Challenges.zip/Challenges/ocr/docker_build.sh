#!/usr/bin/env bash
docker build -t zenhackteam/ocr .
