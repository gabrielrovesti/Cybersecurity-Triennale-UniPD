#!/usr/bin/env bash
docker run -it --rm --name ocr -p 5000:5000 zenhackteam/ocr
