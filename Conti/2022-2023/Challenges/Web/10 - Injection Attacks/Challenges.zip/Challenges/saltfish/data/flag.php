<?php
  $flag = '35c3_password_saltf1sh_30_seconds_max';
