#!/bin/bash
docker build -t zenhackteam/saltfish .
