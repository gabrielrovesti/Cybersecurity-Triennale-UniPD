
<?php
    $db_username = "blog";
    $db_password = "<password_web>";
    $db_database = "blog";
    $db_hostname = "127.0.0.1";
    $conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);
?>
