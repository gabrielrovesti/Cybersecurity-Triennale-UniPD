#!/bin/bash
docker build -t 2018_das_blog .
