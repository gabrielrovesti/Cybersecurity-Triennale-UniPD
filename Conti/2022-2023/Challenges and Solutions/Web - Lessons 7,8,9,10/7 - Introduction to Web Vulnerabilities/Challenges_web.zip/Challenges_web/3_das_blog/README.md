RULES = you cannot access to 'web' and 'other' folders.
