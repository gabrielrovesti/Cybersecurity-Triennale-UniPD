<?php 
header('Location: /%23console.html');
?>
