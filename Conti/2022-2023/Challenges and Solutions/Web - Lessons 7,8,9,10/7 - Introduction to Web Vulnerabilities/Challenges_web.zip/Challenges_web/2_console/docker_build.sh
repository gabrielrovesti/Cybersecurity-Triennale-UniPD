#!/bin/bash
docker build -t zenhackteam/console .
