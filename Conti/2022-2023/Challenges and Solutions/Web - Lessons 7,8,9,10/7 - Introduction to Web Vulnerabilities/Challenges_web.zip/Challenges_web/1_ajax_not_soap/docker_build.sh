#!/bin/bash
docker build -t spritzers/ajax_not_soap .
