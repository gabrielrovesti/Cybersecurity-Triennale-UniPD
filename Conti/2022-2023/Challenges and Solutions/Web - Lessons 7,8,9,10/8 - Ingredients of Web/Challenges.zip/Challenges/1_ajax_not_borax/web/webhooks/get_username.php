<?php
// see if username was given
if(array_key_exists('username', $_GET)){
// simply return the username
  // tideade , can be broken on most md5 code breakers
  echo 'c5644ca91d1307779ed493c4dedfdcb7';
}
?>
