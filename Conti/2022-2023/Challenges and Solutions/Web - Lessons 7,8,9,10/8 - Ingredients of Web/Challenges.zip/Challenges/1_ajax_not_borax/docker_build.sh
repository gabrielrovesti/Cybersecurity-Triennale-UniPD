#!/bin/bash
docker build -t zenhackteam/ajax_not_borax .
