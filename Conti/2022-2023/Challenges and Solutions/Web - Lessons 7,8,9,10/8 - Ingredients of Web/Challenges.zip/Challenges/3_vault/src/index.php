<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Vault</title>
    <link rel="stylesheet" type="text/css" href="/css/main.css">
</head>

<body>
    <div class="main">
        <h1 class="heading">Vault</h1>
        <div class="form">
            <form action="/login.php" method="POST">
                <input type="text" name="username" placeholder="username" required>
                <input type="password" name="password" placeholder="password" required>
                <input type="submit" name="submit" value="submit">
            </form>
        </div>
    <div>
</body>

</html> 
