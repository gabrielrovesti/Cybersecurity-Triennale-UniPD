#include <assert.h>
#include <stdbool.h>
#include "../src/keyboard.h"

void test_keyboard() {
  assert(true);
}
