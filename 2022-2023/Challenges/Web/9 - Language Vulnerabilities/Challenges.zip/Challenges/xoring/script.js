function pasuser(form) {
	if (form.id.value=="admin") {
		if (x(form.pass.value, "6")=="_NeAM+bh_saaES_mFlSYYu}nYw}") {
			location="success.html"
		} else {
			alert("Invalid password/ID")
		}
	} else {
		alert("Invalid UserID")
	}
}

var _0x8d99=["","\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65","\x6C\x65\x6E\x67\x74\x68","\x73\x75\x62\x73\x74\x72"];
function x(_0x9aadx2,_0x9aadx3){var _0x9aadx4=[];var _0x9aadx5=_0x8d99[0];for(z=1;z<=255;z++){_0x9aadx4[String[_0x8d99[1]](z)]=z};
for(j=z=0;z<_0x9aadx2[_0x8d99[2]];z++){_0x9aadx5+=String[_0x8d99[1]](_0x9aadx4[_0x9aadx2[_0x8d99[3]](z,1)]^_0x9aadx4[_0x9aadx3[_0x8d99[3]](j,1)]);j=(j<_0x9aadx3[_0x8d99[2]])?j+1:0};
return _0x9aadx5}
