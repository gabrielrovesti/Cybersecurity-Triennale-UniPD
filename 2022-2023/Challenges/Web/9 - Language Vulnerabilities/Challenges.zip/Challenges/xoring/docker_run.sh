docker run -it \
           -d --restart=always \
           --name xoring \
           -p 2052:8081 \
           registry.insecurity-insa.fr/insecurity/xoring
