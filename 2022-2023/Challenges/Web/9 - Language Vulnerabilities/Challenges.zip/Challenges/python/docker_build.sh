docker build -t registry.insecurity-insa.fr/insecurity/python .
