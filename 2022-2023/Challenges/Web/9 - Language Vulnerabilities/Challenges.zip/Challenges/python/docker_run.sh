docker run -it \
           -d --restart=always \
           --name python \
           -p 2053:5000 \
           registry.insecurity-insa.fr/insecurity/python
